<?php

include_once ESKIL_CORE_INC_PATH . '/header/layouts/divided/helper.php';
include_once ESKIL_CORE_INC_PATH . '/header/layouts/divided/class-eskilcore-divided-header.php';
include_once ESKIL_CORE_INC_PATH . '/header/layouts/divided/dashboard/admin/divided-header-options.php';
include_once ESKIL_CORE_INC_PATH . '/header/layouts/divided/dashboard/meta-box/divided-header-meta-box.php';

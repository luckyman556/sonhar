<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/class-eskilcore-woocommerce.php';

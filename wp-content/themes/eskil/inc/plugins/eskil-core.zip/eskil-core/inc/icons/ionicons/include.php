<?php

include_once ESKIL_CORE_INC_PATH . '/icons/ionicons/class-eskilcore-ionicons-pack.php';

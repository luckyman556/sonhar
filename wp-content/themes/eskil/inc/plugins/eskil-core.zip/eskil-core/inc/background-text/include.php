<?php

include_once ESKIL_CORE_INC_PATH . '/background-text/helper.php';

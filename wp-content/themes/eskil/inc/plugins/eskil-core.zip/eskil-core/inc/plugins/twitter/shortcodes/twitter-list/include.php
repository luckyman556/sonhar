<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-eskilcore-twitter-list-shortcode.php';

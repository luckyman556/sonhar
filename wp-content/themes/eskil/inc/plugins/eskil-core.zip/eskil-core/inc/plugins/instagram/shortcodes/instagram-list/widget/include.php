<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-eskilcore-instagram-list-widget.php';

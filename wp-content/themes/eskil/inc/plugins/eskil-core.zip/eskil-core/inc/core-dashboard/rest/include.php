<?php

include_once ESKIL_CORE_INC_PATH . '/core-dashboard/rest/class-eskilcore-dashboard-rest-api.php';

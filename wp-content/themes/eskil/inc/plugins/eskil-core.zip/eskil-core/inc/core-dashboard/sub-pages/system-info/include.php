<?php

include_once ESKIL_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-eskilcore-dashboard-system-info-page.php';

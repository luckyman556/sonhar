<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-eskilcore-instagram-list-shortcode.php';

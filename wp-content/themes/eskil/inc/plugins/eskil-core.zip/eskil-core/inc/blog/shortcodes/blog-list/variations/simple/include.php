<?php

include_once ESKIL_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/simple/simple.php';

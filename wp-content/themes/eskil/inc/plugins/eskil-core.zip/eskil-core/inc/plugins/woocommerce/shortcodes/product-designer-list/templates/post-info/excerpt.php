<?php
if ( ! empty( $excerpt ) ) { ?>
	<p class="qodef-e-designer-excerpt"><?php echo esc_html( $excerpt ); ?></p>
<?php } ?>

<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-hover/info-hover.php';

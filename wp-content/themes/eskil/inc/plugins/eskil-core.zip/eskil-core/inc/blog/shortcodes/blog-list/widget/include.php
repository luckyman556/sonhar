<?php

include_once ESKIL_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-eskilcore-blog-list-widget.php';
include_once ESKIL_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-eskilcore-simple-blog-list-widget.php';

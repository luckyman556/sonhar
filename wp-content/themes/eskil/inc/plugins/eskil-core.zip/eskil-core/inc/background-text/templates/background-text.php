<div class="qodef-m-background-text-holder" <?php qode_framework_inline_style( $background_text_content_style ); ?>>
	<span class="qodef-m-background-text" <?php qode_framework_inline_style( $background_text_style ); ?>>
		<?php echo esc_html( $text ); ?>
	</span>
</div>

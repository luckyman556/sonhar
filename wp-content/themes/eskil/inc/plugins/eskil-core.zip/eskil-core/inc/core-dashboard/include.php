<?php

include_once ESKIL_CORE_INC_PATH . '/core-dashboard/class-eskilcore-dashboard.php';

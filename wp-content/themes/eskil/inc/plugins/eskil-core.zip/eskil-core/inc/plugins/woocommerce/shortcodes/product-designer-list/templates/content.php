<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-grid-inner clear">
		<?php
		// Include items
		eskil_core_template_part( 'plugins/woocommerce/shortcodes/product-designer-list', 'templates/loop', '', $params );
		?>
	</div>
</div>

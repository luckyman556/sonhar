<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/helper.php';
include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/class-eskilcore-woocommerce-qode-wishlist-for-woocommerce.php';

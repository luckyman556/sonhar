<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/widgets/designer-list/class-eskilcore-woocommerce-designer-list-widget.php';

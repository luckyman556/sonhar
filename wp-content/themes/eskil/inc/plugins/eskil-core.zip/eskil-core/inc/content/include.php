<?php

include_once ESKIL_CORE_INC_PATH . '/content/helper.php';

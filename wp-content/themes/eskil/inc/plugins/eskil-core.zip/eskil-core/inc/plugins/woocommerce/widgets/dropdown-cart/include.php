<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-eskilcore-woocommerce-dropdown-cart-widget.php';

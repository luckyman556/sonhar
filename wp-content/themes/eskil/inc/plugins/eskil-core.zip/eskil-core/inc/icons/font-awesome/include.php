<?php

include_once ESKIL_CORE_INC_PATH . '/icons/font-awesome/class-eskilcore-font-awesome-pack.php';

<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/single/variations/full-width/full-width.php';

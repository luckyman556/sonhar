<?php

include_once ESKIL_CORE_INC_PATH . '/mobile-header/layouts/minimal/helper.php';
include_once ESKIL_CORE_INC_PATH . '/mobile-header/layouts/minimal/class-eskilcore-minimal-mobile-header.php';
include_once ESKIL_CORE_INC_PATH . '/mobile-header/layouts/minimal/dashboard/admin/minimal-mobile-header-options.php';
include_once ESKIL_CORE_INC_PATH . '/mobile-header/layouts/minimal/dashboard/meta-box/minimal-mobile-header-meta-box.php';

<?php

include_once ESKIL_CORE_INC_PATH . '/core-dashboard/sub-pages/import/class-eskilcore-dashboard-import-page.php';
include_once ESKIL_CORE_INC_PATH . '/core-dashboard/sub-pages/import/class-eskilcore-dashboard-import.php';

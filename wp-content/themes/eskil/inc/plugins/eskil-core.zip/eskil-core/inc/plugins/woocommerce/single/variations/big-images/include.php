<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/single/variations/big-images/big-images.php';

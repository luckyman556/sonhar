<?php

include_once ESKIL_CORE_INC_PATH . '/mobile-header/helper.php';
include_once ESKIL_CORE_INC_PATH . '/mobile-header/class-eskilcore-mobile-header.php';
include_once ESKIL_CORE_INC_PATH . '/mobile-header/class-eskilcore-mobile-headers.php';
include_once ESKIL_CORE_INC_PATH . '/mobile-header/template-functions.php';

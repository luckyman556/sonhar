<?php

include_once ESKIL_CORE_INC_PATH . '/header/helper.php';
include_once ESKIL_CORE_INC_PATH . '/header/class-eskilcore-header.php';
include_once ESKIL_CORE_INC_PATH . '/header/class-eskilcore-headers.php';
include_once ESKIL_CORE_INC_PATH . '/header/template-functions.php';

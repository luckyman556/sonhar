<?php

include_once ESKIL_CORE_INC_PATH . '/opener-icon/helper.php';

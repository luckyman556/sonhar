<div class="qodef-m-action">
	<a itemprop="url" href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="qodef-m-action-link"><?php esc_html_e( 'View Cart', 'eskil-core' ); ?></a>
	<a itemprop="url" href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="qodef-m-action-link"><?php esc_html_e( 'Checkout', 'eskil-core' ); ?></a>
</div>

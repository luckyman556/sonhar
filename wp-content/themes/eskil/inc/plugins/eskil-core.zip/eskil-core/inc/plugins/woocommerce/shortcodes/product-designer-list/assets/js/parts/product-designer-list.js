(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.eskil_core_product_designer_list = {};

})( jQuery );

<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-quick-view-for-woocommerce/helper.php';
include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-quick-view-for-woocommerce/class-eskilcore-woocommerce-qode-quick-view-for-woocommerce.php';

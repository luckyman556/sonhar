<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-variation-swatches-for-woocommerce/helper.php';
include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-variation-swatches-for-woocommerce/class-eskilcore-woocommerce-qode-variation-swatches-for-woocommerce.php';

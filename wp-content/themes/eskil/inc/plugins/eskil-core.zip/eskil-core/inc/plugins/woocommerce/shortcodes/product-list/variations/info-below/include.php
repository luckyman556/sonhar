<?php

include_once ESKIL_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-below/info-below.php';

<?php

include_once ESKIL_CORE_INC_PATH . '/blog/single/variations/wide/wide.php';

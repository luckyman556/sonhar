<?php

include_once ESKIL_MEMBERSHIP_INC_PATH . '/widgets/login-opener/class-eskilmembership-login-opener-widget.php';

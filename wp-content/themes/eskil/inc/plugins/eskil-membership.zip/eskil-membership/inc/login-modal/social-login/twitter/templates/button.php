<div class="qodef-m-social-login qodef--twitter">
	<button type="submit" class="qodef-m-social-login-btn" data-social="twitter"><?php echo qode_framework_icons()->render_icon( 'social_twitter', 'elegant-icons' ); ?></button>
</div>
